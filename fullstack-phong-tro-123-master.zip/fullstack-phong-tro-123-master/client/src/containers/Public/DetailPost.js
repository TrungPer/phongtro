import React from 'react'

const DetailPost = () => {
    return (
        <div>DetailPost</div>
    )
}

export default DetailPost